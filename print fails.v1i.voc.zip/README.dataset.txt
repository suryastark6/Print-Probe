# print fails > 2024-04-25 7:16am
https://universe.roboflow.com/stark-zqqep/print-fails

Provided by a Roboflow user
License: CC BY 4.0

